<?php
declare(strict_types=1);
// ONCREATE MED v3 — endpoint independente (não depende de rewrite/cache). PHP 8.0+.
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Content-Security-Policy: default-src \'none\'; frame-ancestors \'none\'');

$cfgFile = __DIR__ . '/private/config.php';
if (!is_file($cfgFile)) { http_response_code(503); echo json_encode(['error' => 'Arquivo de configuração indisponível']); exit; }
$config = require $cfgFile;
$privateDir = __DIR__ . '/private';
$storeFile = $privateDir . '/leads.json';
$lockFile = $privateDir . '/store.lock';
$ipFile = $privateDir . '/login-attempts.json';
$apiUsageFile = $privateDir . '/api-usage.json';
$apiKey = trim((string)($config['mcp_ai_api_key'] ?? ''));
$apiConfigured = preg_match('/^sk_live_[a-zA-Z0-9_-]{8,}$/', $apiKey) === 1;
require_once __DIR__ . '/oncreate-inpi-v3.php';
$isHttps = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') === '443');
$localTest = getenv('ONCREATE_LOCAL_TEST') === '1' && in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true);
if (!$isHttps && !$localTest) { http_response_code(426); echo json_encode(['error'=>'Ative o HTTPS/SSL do subdomínio no cPanel antes de entrar no painel.']); exit; }

ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.gc_maxlifetime', '604800');
session_name('ONMEDSESSID');
session_set_cookie_params(['lifetime'=>0, 'path'=>'/', 'secure'=>$isHttps, 'httponly'=>true, 'samesite'=>'Strict']);
session_start();

function reply(int $code, array $body): never { http_response_code($code); echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit; }
function safeStr(mixed $v, int $limit=250): string { return function_exists('mb_substr') ? mb_substr(trim(is_string($v) ? $v : ''), 0, $limit, 'UTF-8') : substr(trim(is_string($v) ? $v : ''), 0, $limit); }
function validateUrl(string $v): bool { return $v === '' || (filter_var($v, FILTER_VALIDATE_URL) !== false && strtolower((string)parse_url($v, PHP_URL_SCHEME)) === 'https'); }
function safeBody(): array {
    if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== 0) reply(415, ['error'=>'Envie JSON']);
    $length = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($length > 15000) reply(413, ['error'=>'Dados muito grandes']);
    $raw = file_get_contents('php://input', false, null, 0, 15001);
    if ($raw === false || strlen($raw) > 15000) reply(413, ['error'=>'Dados muito grandes']);
    $val = json_decode($raw, true);
    if (!is_array($val)) reply(400, ['error'=>'JSON inválido']);
    return $val;
}
function readDataUnlocked(string $path): array {
    if (!file_exists($path)) return [];
    $json = file_get_contents($path);
    if ($json === false) throw new RuntimeException('Falha de leitura');
    $data = json_decode($json, true);
    if (!is_array($data)) throw new RuntimeException('Arquivo de dados inválido');
    return $data;
}
function storeDataUnlocked(string $path, array $data): void {
    $tmp = $path . '.' . bin2hex(random_bytes(6)) . '.tmp';
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    if (file_put_contents($tmp, $json) === false) throw new RuntimeException('Erro ao salvar arquivo. Confira permissões da pasta private.');
    @chmod($tmp, 0600);
    if (!rename($tmp, $path)) { @unlink($tmp); throw new RuntimeException('Erro ao concluir gravação'); }
}
function withStore(callable $fn): mixed {
    global $storeFile,$lockFile;
    $lock = fopen($lockFile, 'c+');
    if ($lock === false) throw new RuntimeException('A pasta private precisa permitir escrita pelo PHP');
    try {
        if (!flock($lock, LOCK_EX)) throw new RuntimeException('Não foi possível obter bloqueio');
        $data = readDataUnlocked($storeFile);
        return $fn($data, $storeFile);
    } finally { flock($lock, LOCK_UN); fclose($lock); }
}
const PROFESSIONS = ['Nutricionista', 'Psicóloga(o)', 'Médico(a)', 'Fisioterapeuta'];
const TRADEMARK = ['nao_verificado', 'registro_em_vigor', 'pedido_em_andamento', 'registro_extinto', 'pedido_indeferido', 'nenhum_resultado_localizado', 'inconclusivo'];
const SALES = ['novo', 'qualificado', 'contatado', 'reuniao', 'convertido', 'descartado'];
function normalizeLead(array $src, ?array $old): array {
    $tm = in_array($src['trademarkStatus'] ?? '', TRADEMARK, true) ? $src['trademarkStatus'] : 'nao_verificado';
    $lead = [
        'id'=>$old['id'] ?? uuid4(),
        'brandName'=>safeStr($src['brandName'] ?? '', 180),
        'legalName'=>safeStr($src['legalName'] ?? '', 180),
        'profession'=>in_array($src['profession'] ?? '', PROFESSIONS, true) ? $src['profession'] : 'Médico(a)',
        'trademarkStatus'=>$tm,
        'salesStatus'=>in_array($src['salesStatus'] ?? '', SALES, true) ? $src['salesStatus'] : 'novo',
        'processNumber'=>safeStr($src['processNumber'] ?? '', 9),
        'sourceUrl'=>safeStr($src['sourceUrl'] ?? '', 600),
        'observations'=>safeStr($src['observations'] ?? '', 2000),
        'lookupMatches'=>$old['lookupMatches'] ?? [],
        'lookupQueries'=>$old['lookupQueries'] ?? [],
        'lookupProvider'=>$old['lookupProvider'] ?? null,
        'lookupSummary'=>$old['lookupSummary'] ?? null,
        'checkedAt'=>$old['checkedAt'] ?? null,
        'createdAt'=>$old['createdAt'] ?? gmdate('Y-m-d\TH:i:s\Z'),
        'updatedAt'=>gmdate('Y-m-d\TH:i:s\Z'),
    ];
    if ((function_exists('mb_strlen') ? mb_strlen($lead['brandName']) : strlen($lead['brandName'])) < 3) reply(400,['error'=>'Informe um nome com pelo menos 3 caracteres']);
    if (!validateUrl($lead['sourceUrl'])) reply(400,['error'=>'A URL da fonte deve começar com https://']);
    if ($lead['processNumber'] !== '' && !preg_match('/^\d{9}$/', $lead['processNumber'])) reply(400,['error'=>'O processo do INPI deve ter 9 dígitos']);
    if (in_array($tm, ['registro_em_vigor','pedido_em_andamento','registro_extinto','pedido_indeferido'], true) && (!$lead['processNumber'] || !$lead['sourceUrl'])) {
        reply(400,['error'=>'Para registrar situação de processo, informe número com 9 dígitos e URL da fonte']);
    }
    if ($tm !== 'nao_verificado' && ($tm !== ($old['trademarkStatus'] ?? null) || $lead['processNumber'] !== ($old['processNumber'] ?? '') || $lead['sourceUrl'] !== ($old['sourceUrl'] ?? ''))) $lead['checkedAt'] = gmdate('Y-m-d\TH:i:s\Z');
    if ($tm === 'nao_verificado') $lead['checkedAt'] = null;
    return $lead;
}
function uuid4(): string { $b=random_bytes(16); $b[6]=chr((ord($b[6])&0x0f)|0x40); $b[8]=chr((ord($b[8])&0x3f)|0x80); $s=bin2hex($b); return substr($s,0,8).'-'.substr($s,8,4).'-'.substr($s,12,4).'-'.substr($s,16,4).'-'.substr($s,20); }
function csvCell(mixed $v): string { $v=(string)($v ?? ''); if (preg_match('/^\s*[=+@\-]/', $v)) $v="'".$v; return '"'.str_replace('"','""',$v).'"'; }
function authenticated(array $config): bool { return ($_SESSION['logged_in'] ?? false) === true && ($_SESSION['pass_version'] ?? '') === hash('sha256', $config['password_hash']); }

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$path = $_GET['route'] ?? '';
if (!is_string($path) || !preg_match('~^/api/[a-zA-Z0-9._/-]{1,140}$~', $path)) reply(404,['error'=>'Rota inválida']);
if (in_array($method, ['POST','PATCH','DELETE'], true) && ($_SERVER['HTTP_X_ONCREATE_REQUEST'] ?? '') !== '1') reply(403,['error'=>'Requisição de segurança não autorizada']);
if ($path === '/api/version' && $method === 'GET') reply(200,['build'=>'3.1.0','ok'=>true]);
if ($path === '/api/session' && $method === 'GET') reply(200,['authenticated'=>authenticated($config), 'integration'=>$apiConfigured, 'provider'=>$apiConfigured?'MCP.ai (terceiro)':'Não configurado']);
if ($path === '/api/login' && $method === 'POST') {
    $body = safeBody();
    $password = safeStr($body['password'] ?? '',300);
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown');
    $fh = fopen($ipFile,'c+');
    if ($fh === false) reply(500,['error'=>'A pasta private precisa permitir escrita']);
    try {
        flock($fh, LOCK_EX);
        $raw = stream_get_contents($fh);
        $attempts = $raw ? json_decode($raw, true) : [];
        if (!is_array($attempts)) $attempts=[];
        $now=time(); $key=hash('sha256',$ip);
        foreach ($attempts as $a=>$info) { if ($now-(int)($info['since'] ?? 0)>900) unset($attempts[$a]); }
        $entry=$attempts[$key] ?? ['count'=>0,'since'=>$now];
        if ($entry['count']>=8) reply(429,['error'=>'Muitas tentativas. Tente em 15 minutos.']);
        $success = password_verify($password, $config['password_hash']);
        if ($success) unset($attempts[$key]); else { $entry['count']++; $attempts[$key]=$entry; }
        rewind($fh); ftruncate($fh,0); fwrite($fh,json_encode($attempts)); fflush($fh);
    } finally { flock($fh,LOCK_UN); fclose($fh); }
    if (!$success) reply(401,['error'=>'Senha incorreta']);
    session_regenerate_id(true);
    $_SESSION['logged_in']=true;
    $_SESSION['pass_version']=hash('sha256',$config['password_hash']);
    reply(200,['ok'=>true]);
}
if (!authenticated($config)) reply(401,['error'=>'Acesso não autorizado']);
if ($path === '/api/logout' && $method === 'POST') { $_SESSION=[]; session_destroy(); reply(200,['ok'=>true]); }
try {
    if ($path === '/api/leads' && $method === 'GET') {
        $result = withStore(fn($db,$path)=>$db);
        reply(200,['leads'=>$result]);
    }
    if ($path === '/api/leads' && $method === 'POST') {
        $b = safeBody();
        $lead = normalizeLead($b,null);
        withStore(function($db,$path) use($lead){ array_unshift($db,$lead); storeDataUnlocked($path,$db); });
        reply(201,['lead'=>$lead]);
    }
    if ($path === '/api/export.csv' && $method === 'GET') {
        $db=withStore(fn($db,$path)=>$db);
        $cols=['brandName','legalName','profession','trademarkStatus','processNumber','sourceUrl','checkedAt','salesStatus','observations','createdAt','updatedAt'];
        header_remove('Content-Type'); header('Content-Type: text/csv; charset=UTF-8'); header('Content-Disposition: attachment; filename="oncreatemed-leads.csv"');
        echo "\xEF\xBB\xBF".implode(';',$cols)."\r\n";
        foreach ($db as $entry) echo implode(';',array_map(fn($k)=>csvCell($entry[$k] ?? ''),$cols))."\r\n";
        exit;
    }
    if ($path === '/api/lookup' && $method === 'POST') {
        if (!$apiConfigured) reply(503,['code'=>'NOT_CONFIGURED','error'=>'Configure sua chave MCP.ai em private/config.php para habilitar a consulta automática.']);
        $b=safeBody(); $id=safeStr($b['leadId']??'',36); $force=($b['force']??false)===true;
        // Clientes da primeira versão enviavam {query, mode} em vez de {leadId}.
        // Não tente consultar/cobrar créditos com um protocolo incompatível.
        if (!isset($b['leadId']) && (isset($b['query']) || isset($b['mode']))) {
            reply(409,['code'=>'OUTDATED_FRONTEND','error'=>'Interface antiga detectada. Substitua index.html e app.js pela versão 2.1, depois use Ctrl+Shift+R (no Mac: Cmd+Shift+R).']);
        }
        if (!preg_match('/^[a-f0-9-]{36}$/i',$id)) reply(400,['code'=>'INVALID_LEAD_ID','error'=>'Identificador de pesquisa inválido. Atualize a página e crie uma nova pesquisa.']);
        $lead=withStore(function($db,$p)use($id){foreach($db as $l)if($l['id']===$id)return $l;return null;});
        if (!$lead) reply(404,['error'=>'Profissional não encontrado']);
        $last=(int)strtotime($lead['checkedAt']??'');
        if (!$force && ($lead['lookupProvider']??'')==='MCP.ai' && $last>0 && time()-$last<86400) {
            reply(200,['cached'=>true,'results'=>$lead['lookupMatches']??[],'summary'=>$lead['lookupSummary']??'', 'status'=>$lead['trademarkStatus'], 'terms'=>$lead['lookupQueries']??[], 'checkedAt'=>$lead['checkedAt'],'source'=>'MCP.ai (dados do INPI; fornecedor terceiro)','complete'=>true]);
        }
        // Controle diário de chamadas para evitar cobrança inesperada em repetições.
        $usage=fopen($apiUsageFile,'c+');
        if (!$usage) reply(500,['error'=>'Sem permissão para gravar o limite de consultas em private/']);
        try {
            flock($usage,LOCK_EX); $raw=stream_get_contents($usage); $usageData=json_decode($raw?:'{}',true);
            if (!is_array($usageData)) $usageData=[];
            $day=gmdate('Y-m-d'); $count=($usageData['day']??'')===$day?(int)($usageData['count']??0):0;
            $needed=count(inpiQueries($lead['brandName']));
            $max=max(2,min(100,(int)($config['daily_api_request_limit']??20)));
            if ($count+$needed>$max) reply(429,['error'=>'Limite de solicitações externas do dia atingido. Ajuste daily_api_request_limit no servidor se necessário.']);
            $usageData=['day'=>$day,'count'=>$count+$needed];
            rewind($usage);ftruncate($usage,0);fwrite($usage,json_encode($usageData));fflush($usage);
        } finally {flock($usage,LOCK_UN);fclose($usage);}
        $all=[]; $terms=inpiQueries($lead['brandName']);
        foreach ($terms as $term) {
            try { $found=inpiFetch($apiKey,$term); }
            catch (RuntimeException $providerError) {
                $fields=['code'=>'PROVIDER_ERROR','error'=>$providerError->getMessage(),
                  'attemptedAt'=>gmdate('Y-m-d\TH:i:s\Z'), 'provider'=>'MCP.ai'];
                if ($providerError instanceof OncreateProviderException) {
                    $fields['providerHttpStatus']=$providerError->providerHttpStatus;
                    if ($providerError->providerRequestId!=='') $fields['providerRequestId']=$providerError->providerRequestId;
                    if ($providerError->providerErrorCode!=='') $fields['providerErrorCode']=$providerError->providerErrorCode;
                }
                error_log('ONCREATE MED: pesquisa externa falhou, status HTTP '.(string)($fields['providerHttpStatus']??0).', request-id '.(string)($fields['providerRequestId']??'ausente'));
                reply(502,$fields);
            }
            foreach($found as $m)$all[$m['process']]=$m;
        }
        $matches=array_values($all); [$status,$summary]=inpiResultStatus($matches,$lead['brandName']);
        $date=gmdate('Y-m-d\TH:i:s\Z');
        withStore(function($db,$path)use($id,$matches,$terms,$status,$summary,$date){
            foreach($db as $i=>$record)if($record['id']===$id){
                $db[$i]['lookupMatches']=array_slice($matches,0,100);
                $db[$i]['lookupQueries']=$terms;
                $db[$i]['lookupProvider']='MCP.ai';
                $db[$i]['lookupSummary']=$summary;
                $db[$i]['checkedAt']=$date;
                $db[$i]['trademarkStatus']=$status;
                $db[$i]['updatedAt']=$date;
                if($status==='registro_em_vigor'||$status==='pedido_em_andamento'){
                    foreach($matches as $match){if(inpiNorm($match['brand'])===inpiNorm($record['brandName'])||inpiNorm($match['brand'])===inpiNorm(inpiCore($record['brandName']))){
                       $db[$i]['processNumber']=$match['process'];$db[$i]['sourceUrl']=$match['sourceUrl'];break;
                    }}
                }
                storeDataUnlocked($path,$db);return;
            }
            throw new RuntimeException('Lead foi removido durante a consulta.');
        });
        reply(200,['cached'=>false,'results'=>array_slice($matches,0,100),'summary'=>$summary,'status'=>$status,'terms'=>$terms,'checkedAt'=>$date,'source'=>'MCP.ai (dados do INPI; fornecedor terceiro)','complete'=>true]);
    }
    if (preg_match('~^/api/leads/([a-f0-9-]{36})$~i',(string)$path,$match)) {
        $id=$match[1];
        if ($method === 'PATCH') {
            $b=safeBody();
            $lead=withStore(function($db,$path)use($b,$id){
                foreach($db as $i=>$old) if($old['id']===$id) { $new=normalizeLead(array_merge($old,$b),$old);$db[$i]=$new;storeDataUnlocked($path,$db);return $new; }
                reply(404,['error'=>'Lead não encontrado']);
            });
            reply(200,['lead'=>$lead]);
        }
        if ($method === 'DELETE') {
            withStore(function($db,$path)use($id){
                foreach($db as $i=>$old) if($old['id']===$id) { array_splice($db,$i,1);storeDataUnlocked($path,$db);return; }
                reply(404,['error'=>'Lead não encontrado']);
            });
            reply(200,['ok'=>true]);
        }
    }
    reply(404,['error'=>'Rota não encontrada']);
} catch(Throwable $e) { error_log('ONCREATE MED: '.$e->getMessage()); reply(500,['error'=>'Falha interna. Verifique permissões da pasta private e o log de erros PHP.']); }
