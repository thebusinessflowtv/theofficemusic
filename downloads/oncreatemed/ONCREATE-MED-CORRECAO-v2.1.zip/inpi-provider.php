<?php
/** ONCREATE MED — adaptador somente-leitura para API privada MCP.ai (NÃO é API oficial do INPI).
 *  Nunca deve ser acessado diretamente via web. Incluído em api.php após autenticação.
 */
declare(strict_types=1);

function inpiNorm(string $input): string {
    $x = trim($input);
    if (function_exists('iconv')) $x = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $x) ?: $x;
    $x = strtolower($x);
    return trim(preg_replace('/\s+/', ' ', preg_replace('/[^a-z0-9 ]/', ' ', $x) ?? '') ?? '');
}
function inpiCore(string $name): string {
    $x = trim(preg_replace('/^(dr\.?|dra\.?)\s+/iu','',$name) ?? $name);
    $x = trim(preg_replace('/\s*[-–|,]?\s*(nutricionista|nutricao|nutrição|psicóloga|psicologo|psicóloga|psicólogo|medico|médico|médica|fisioterapeuta)(\s+cl[ií]nic[ao])?\s*$/iu', '', $x) ?? $x);
    return (function_exists('mb_strlen') ? mb_strlen($x) : strlen($x)) >= 3 ? $x : $name;
}
function inpiQueries(string $brand): array {
    $full = trim($brand); $base = inpiCore($full);
    return inpiNorm($base) === inpiNorm($full) ? [$full] : [$base,$full];
}
function inpiList(array $v): bool { return $v === [] || array_keys($v) === range(0,count($v)-1); }
function inpiArrayResult(mixed $v): array {
    if (is_array($v) && inpiList($v)) return $v;
    if (!is_array($v)) throw new RuntimeException('A API respondeu em formato não reconhecido (resultado). Nenhum status foi concluído.');
    foreach(['resultados','marcas','processos','results','items','records','data','lista','hits','resultado'] as $key) {
        if (array_key_exists($key,$v)) {
            $d=$v[$key];
            if ($key === 'hits' && is_array($d) && array_key_exists('hits',$d)) $d=$d['hits'];
            if (is_array($d) && inpiList($d)) return $d;
            if (is_array($d)) return inpiArrayResult($d);
        }
    }
    // Uma resposta vazia só é conclusão quando acompanhada de contagem explícita.
    foreach (['total','count','total_results','totalResultados'] as $count) if (isset($v[$count]) && (int)$v[$count] === 0) return [];
    throw new RuntimeException('A API não forneceu uma lista de processos identificável. Não é seguro afirmar que a marca não foi encontrada.');
}
function inpiField(array $record, array $keys): string {
    foreach ($keys as $key) if (isset($record[$key]) && is_scalar($record[$key])) return trim((string)$record[$key]);
    return '';
}
function inpiMark(array $record): array {
    $name = inpiField($record,['marca','nome_marca','nomeMarca','nome','brand','titulo','title']);
    $process = preg_replace('/\D/','',inpiField($record,['numero_processo','numeroProcesso','numero','processo','process','number','pedido'])) ?? '';
    $class = inpiField($record,['classe','ncl','classe_nice','classeNice','niceClass','class']);
    $status = inpiField($record,['situacao','situação','status','situacao_registro','situacaoRegistro','andamento']);
    $holder = inpiField($record,['titular','nome_titular','nomeTitular','holder','requerente','depositante']);
    if ($holder === '') {
        foreach(['titulares','requerentes','depositantes'] as $k) if (isset($record[$k][0]) && is_array($record[$k][0])) { $holder=inpiField($record[$k][0],['nome','nome_titular','name','razao_social']);break; }
    }
    if ($name === '' || !preg_match('/^\d{9}$/', $process)) return [];
    return [
       'brand'=>safeStr($name,200),'process'=>$process,'niceClass'=>safeStr($class,20),
       'status'=>safeStr($status,180),'holder'=>safeStr($holder,250),
       'sourceUrl'=>'https://servicos.busca.inpi.gov.br/marcas',
    ];
}
function inpiFetch(string $key,string $brand): array {
    $endpoint='https://api.mcp.ai/api/inpi/marcas/busca';
    $post=json_encode(['marca'=>$brand,'ncl'=>'44'],JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
    $headers=['Content-Type: application/json','Accept: application/json','Authorization: Bearer '.$key];
    $body=false;$http=0;
    if (function_exists('curl_init')) {
        $ch=curl_init($endpoint);
        curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$post,CURLOPT_HTTPHEADER=>$headers,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>4,CURLOPT_TIMEOUT=>11,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_MAXREDIRS=>0]);
        $body=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
    } else {
        $context=stream_context_create(['http'=>['method'=>'POST','header'=>implode("\r\n",$headers),'content'=>$post,'timeout'=>11,'ignore_errors'=>true,'follow_location'=>0], 'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]]);
        $body=@file_get_contents($endpoint,false,$context);
        foreach (($http_response_header ?? []) as $line) if (preg_match('/^HTTP\/\S+\s+(\d+)/',$line,$m)) {$http=(int)$m[1]; break;}
    }
    if ($body===false || $http===0) throw new RuntimeException('Não foi possível conectar à API. Confira a conexão externa HTTPS do servidor.');
    if ($http===401 || $http===403) throw new RuntimeException('Chave da API inválida ou sem permissão.');
    if ($http===402 || $http===429) throw new RuntimeException('Limite/créditos da API atingidos. Consulte sua conta no provedor.');
    if ($http<200 || $http>=300) throw new RuntimeException('O provedor não respondeu com sucesso (HTTP '.$http.').');
    if (strlen($body)>1500000) throw new RuntimeException('Resposta excessivamente grande da API.');
    $parsed=json_decode($body,true);
    if (!is_array($parsed) || !array_key_exists('ok',$parsed) || $parsed['ok']!==true) throw new RuntimeException('O provedor retornou erro ou formato de resposta não validado.');
    if (!array_key_exists('result',$parsed)) throw new RuntimeException('A API retornou sucesso sem campo result.');
    $raw=inpiArrayResult($parsed['result']);
    $total=(int)(is_array($parsed['result'])?($parsed['result']['total']??$parsed['result']['total_results']??count($raw)):count($raw));
    if ($total>count($raw) || count($raw)>=100) throw new RuntimeException('Consulta com paginação ou mais de 100 resultados. Não é possível concluir uma busca incompleta.');
    $items=[];
    foreach($raw as $entry){if(!is_array($entry)) continue;$record=inpiMark($entry);if($record) $items[]=$record;}
    if ($raw && !$items) throw new RuntimeException('Formato dos registros não reconhecido. Nenhum resultado foi descartado silenciosamente.');
    return $items;
}
function inpiResultStatus(array $marks,string $brand): array {
    if (!$marks) return ['nenhum_resultado_localizado','Nenhuma correspondência retornada para as variantes pesquisadas. Isso NÃO comprova disponibilidade.'];
    foreach ($marks as $m) {
        if (inpiNorm($m['brand'])!==inpiNorm($brand) && inpiNorm($m['brand'])!==inpiNorm(inpiCore($brand))) continue;
        $raw=inpiNorm($m['status']);
        if (preg_match('/(indeferid|extint|arquivad|cancelad|caduc|nulid|inativ|nao registrada)/',$raw)) continue;
        if (preg_match('/(registro em vigor|registrada|registro concedido|vigente|\bativa\b)/',$raw)) return ['registro_em_vigor','Marca de nome correspondente com indicação de registro vigente; confira o titular no INPI.'];
        if (preg_match('/(depositad|em exame|pedido em andamento|aguardando|oposicao|publicado)/',$raw)) return ['pedido_em_andamento','Pedido encontrado; a concessão não está confirmada.'];
    }
    return ['inconclusivo','Foram encontradas marcas potencialmente relacionadas. Confira os processos e os titulares.'];
}
