'use strict';
const $ = id => document.getElementById(id);
const OFFICIAL_URL = 'https://servicos.busca.inpi.gov.br/marcas';
let leads = [], currentLeadId = null, currentTerms = [], autoEnabled = false;
const TM = {
  nao_verificado:['Não verificado','neutral'],
  registro_em_vigor:['Registro em vigor','active'],
  pedido_em_andamento:['Pedido em andamento','pending'],
  registro_extinto:['Registro extinto','danger'],
  pedido_indeferido:['Pedido indeferido','danger'],
  nenhum_resultado_localizado:['Sem resultado localizado','soft'],
  inconclusivo:['Inconclusivo','neutral'],
};
const SALES = {novo:'Novo lead',qualificado:'Qualificado',contatado:'Contatado',reuniao:'Reunião',convertido:'Convertido',descartado:'Descartado'};
function escapeHTML(v) { return String(v ?? '').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function toast(msg) { $('toast').textContent=msg; $('toast').classList.remove('hidden');clearTimeout(toast.timeout);toast.timeout=setTimeout(()=>$('toast').classList.add('hidden'),3600); }
async function api(url,options={}) {
  const res=await fetch(url,{credentials:'same-origin',...options,headers:{...(options.body?{'Content-Type':'application/json'}:{}),'X-ONCREATE-REQUEST':'1',...(options.headers||{})}});
  let value={};try { value=await res.json(); } catch { value={error:`Erro HTTP ${res.status}`}; }
  if (!res.ok) throw new Error(value.error||`Erro HTTP ${res.status}`);
  return value;
}
async function loadSession(){
  try {let s=await api('/api/session');autoEnabled=!!s.integration;
    $('loginScreen').classList.toggle('hidden',s.authenticated);
    $('app').classList.toggle('hidden',!s.authenticated);
    $('autoLookupSection').classList.toggle('hidden',!autoEnabled);
    if(s.authenticated) await loadLeads();
  } catch(err) { $('loginScreen').classList.remove('hidden'); $('loginError').textContent=err.message||'Sem conexão com o servidor.'; }
}
$('loginForm').addEventListener('submit',async e=>{
 e.preventDefault();$('loginError').textContent='';
 const btn=e.submitter;btn.disabled=true;
 try {await api('/api/login',{method:'POST',body:JSON.stringify({password:$('password').value})}); $('password').value='';await loadSession();toast('Acesso autorizado.');}
 catch(err){$('loginError').textContent=err.message;}
 finally{btn.disabled=false;}
});
$('logoutBtn').addEventListener('click',async()=>{try{await api('/api/logout',{method:'POST',body:'{}'})}catch{}leads=[];currentLeadId=null;$('searchWorkspace').classList.add('hidden');await loadSession()});
function normalize(value){return String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()}
function coreBrand(name){
 let t=name.trim().replace(/^(dr\.?|dra\.?)\s+/i,'').replace(/\s+\|\s+.*$/,'');
 t=t.replace(/\s*[-–|,]?\s*(nutricionista|nutri[cç][aã]o|psic[oó]log[ao]|m[eé]dic[oa]|fisioterapeuta)(\s+cl[ií]nic[ao])?\s*$/i,'').trim();
 return t.length>=3?t:name.trim();
}
function cleanHolder(s){return s.replace(/\s+(ltda\.?|eireli|s\/?a|me|epp)\s*$/i,'').trim()}
function getTerms(brand,legal){
 const candidates=[{type:'brand',label:'MARCA · NOME COMPLETO',query:brand},{type:'brand',label:'MARCA · NOME PRINCIPAL',query:coreBrand(brand)}];
 if(legal) {candidates.push({type:'holder',label:'TITULAR · RAZÃO SOCIAL',query:legal});if(cleanHolder(legal)!==legal)candidates.push({type:'holder',label:'TITULAR · NOME SEM SUFIXO',query:cleanHolder(legal)})}
 const seen=new Set();return candidates.filter(x=>{let k=x.type+':'+normalize(x.query);if(seen.has(k))return false;seen.add(k);return true});
}
async function loadLeads(){const r=await api('/api/leads');leads=r.leads||[];renderLeads();}
function renderTerms(lead){
 currentLeadId=lead.id;
 currentTerms=getTerms(lead.brandName,lead.legalName);
 $('workspaceTitle').textContent=lead.brandName;
 $('searchTerms').innerHTML=currentTerms.map((t,i)=>`<div class="term"><div><span>${escapeHTML(t.label)}</span><strong>${escapeHTML(t.query)}</strong></div><div class="term-actions"><button type="button" class="mini-btn" data-term="${i}" data-task="copy">Copiar termo</button><button type="button" class="mini-btn dark" data-term="${i}" data-task="open">Abrir INPI ↗</button></div></div>`).join('');
 $('searchWorkspace').classList.remove('hidden');
 $('autoLookupResults').innerHTML='';
 if(location.hash!=='#pesquisa')location.hash='pesquisa';
 $('searchWorkspace').scrollIntoView({behavior:'smooth',block:'center'});
}
$('searchForm').addEventListener('submit',async e=>{
 e.preventDefault();$('searchError').textContent='';
 const btn=$('createSearchBtn');btn.disabled=true;
 try{
  const lead={brandName:$('brandName').value,legalName:$('legalName').value,profession:$('profession').value};
  const r=await api('/api/leads',{method:'POST',body:JSON.stringify(lead)});
  leads.unshift(r.lead);renderLeads();renderTerms(r.lead);toast('Pesquisa preparada e profissional salvo.');
 }catch(err){$('searchError').textContent=err.message}
 finally{btn.disabled=false}
});
$('searchTerms').addEventListener('click',async e=>{
 const btn=e.target.closest('[data-task]');if(!btn)return;
 const term=currentTerms[Number(btn.dataset.term)];if(!term)return;
 if(btn.dataset.task==='open'){
   window.open(OFFICIAL_URL,'_blank','noopener,noreferrer');
   try{await navigator.clipboard.writeText(term.query);toast('Termo copiado. Cole-o na busca do INPI.')}catch{toast('Busca aberta. Copie manualmente o termo exibido.')}
 } else {
   try{await navigator.clipboard.writeText(term.query);toast('Termo copiado.')}catch{toast('Selecione o termo na tela para copiar.')}
 }
});
$('autoLookupBtn').addEventListener('click',async()=>{
 if(!autoEnabled||!currentTerms.length)return;
 let html=[];const btn=$('autoLookupBtn');btn.disabled=true;
 $('autoLookupResults').textContent='Consultando a fonte integrada...';
 try{
   for(const term of currentTerms){
     const r=await api('/api/lookup',{method:'POST',body:JSON.stringify({query:term.query,mode:term.type})});
     html.push(`<div class="auto-result"><strong>${escapeHTML(term.label)} · ${escapeHTML(term.query)}</strong><div>Fonte: ${escapeHTML(r.source||'API configurada')} · Atualização informada: ${escapeHTML(r.asOf||'não disponível')}</div>${r.results.length?r.results.map(x=>`<p><b>${escapeHTML(x.brand)}</b> · ${escapeHTML(x.holder)} · Proc.: ${escapeHTML(x.process)} · Classe ${escapeHTML(x.niceClass)} · ${escapeHTML(x.status)} ${x.sourceUrl?`· <a href="${escapeHTML(x.sourceUrl)}" target="_blank" rel="noopener noreferrer">Fonte ↗</a>`:''}</p>`).join(''):'Nenhuma correspondência reportada para esta variante pela fonte integrada. Isso não comprova disponibilidade.'}</div>`);
   }
   $('autoLookupResults').innerHTML=html.join('');
 }catch(err){$('autoLookupResults').textContent='Consulta automática indisponível: '+err.message}
 finally{btn.disabled=false}
});
$('verifyOpenBtn').addEventListener('click',()=>{if(currentLeadId)openModal(currentLeadId)});
function dateBR(iso){return iso?new Date(iso).toLocaleDateString('pt-BR'):'—'}
function renderLeads(){
 const q=normalize($('listQuery').value),p=$('filterProfession').value,t=$('filterTrademark').value;
 const filtered=leads.filter(l=>(!p||l.profession===p)&&(!t||l.trademarkStatus===t)&&(!q||normalize([l.brandName,l.legalName,l.processNumber].join(' ')).includes(q)));
 $('statTotal').textContent=leads.length;
 $('statUnchecked').textContent=leads.filter(l=>l.trademarkStatus==='nao_verificado').length;
 $('statNoMatch').textContent=leads.filter(l=>l.trademarkStatus==='nenhum_resultado_localizado').length;
 $('statPipeline').textContent=leads.filter(l=>['qualificado','contatado','reuniao'].includes(l.salesStatus)).length;
 $('navCount').textContent=leads.length;
 $('leadRows').innerHTML=filtered.map(l=>{
  const status=TM[l.trademarkStatus]||TM.nao_verificado;
  return `<tr><td><div class="name-cell">${escapeHTML(l.brandName)}</div>${l.legalName?`<div class="legal-cell" title="${escapeHTML(l.legalName)}">${escapeHTML(l.legalName)}</div>`:''}</td><td>${escapeHTML(l.profession)}</td><td><span class="status ${status[1]}">${status[0]}</span></td><td>${escapeHTML(SALES[l.salesStatus]||'Novo lead')}</td><td>${dateBR(l.checkedAt)}</td><td><button class="row-action" type="button" data-edit="${l.id}">Ver / editar →</button></td></tr>`;
 }).join('');
 $('emptyState').classList.toggle('hidden',filtered.length>0);
 $('rowsCount').textContent=filtered.length+' registro'+(filtered.length!==1?'s':'');
}
['listQuery','filterProfession','filterTrademark'].forEach(id=>$(id).addEventListener('input',renderLeads));
$('leadRows').addEventListener('click',e=>{
 const btn=e.target.closest('[data-edit]');if(btn)openModal(btn.dataset.edit)
});
function openModal(id){
 const lead=leads.find(x=>x.id===id);if(!lead)return;
 currentLeadId=id;
 $('modalStatus').value=lead.trademarkStatus;
 $('modalSales').value=lead.salesStatus;
 $('modalProcess').value=lead.processNumber;
 $('modalSource').value=lead.sourceUrl;
 $('modalNotes').value=lead.observations;
 $('modalTitle').textContent='Verificar · '+lead.brandName;
 $('verifyError').textContent='';
 $('modal').classList.remove('hidden');
 $('modalStatus').focus();
}
function closeModal(){$('modal').classList.add('hidden');$('verifyError').textContent=''}
$('closeModal').addEventListener('click',closeModal);
$('cancelModal').addEventListener('click',closeModal);
$('modal').addEventListener('click',e=>{if(e.target===$('modal'))closeModal()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('modal').classList.contains('hidden'))closeModal()});
$('verifyForm').addEventListener('submit',async e=>{
 e.preventDefault();$('verifyError').textContent='';
 const btn=e.submitter;btn.disabled=true;
 try{
  const patch={trademarkStatus:$('modalStatus').value,salesStatus:$('modalSales').value,processNumber:$('modalProcess').value,sourceUrl:$('modalSource').value,observations:$('modalNotes').value};
  const r=await api(`/api/leads/${currentLeadId}`,{method:'PATCH',body:JSON.stringify(patch)});
  leads=leads.map(l=>l.id===r.lead.id?r.lead:l);
  closeModal();renderLeads();toast('Verificação e prospecção atualizadas.');
 }catch(err){$('verifyError').textContent=err.message}
 finally{btn.disabled=false}
});
loadSession();
