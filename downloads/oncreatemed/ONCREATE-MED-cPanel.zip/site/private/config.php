<?php
// Configure um hash de senha com password_hash() no servidor, ANTES do primeiro login.
return ['password_hash' => 'TROQUE_PELO_HASH_GERADO_NO_CPANEL'];
